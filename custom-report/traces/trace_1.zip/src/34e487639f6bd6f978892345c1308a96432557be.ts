import {test, expect} from "@playwright/test";
import dotenv from "dotenv";
import path from "path";
import { homePage } from "../../pages/enduserpages/homePage";

dotenv.config({path: path.resolve(process.cwd(),'.env')});

test("User Should be able to Register Himself", async({page}) => {
    const baseURL = process.env.BASE_URL_WEB;
    if(baseURL) {
        await page.goto(baseURL);
        const endUserHomePage = new homePage(page);
        await endUserHomePage.clickMyAccountBtn();
        await page.waitForTimeout(5000);
    }
});