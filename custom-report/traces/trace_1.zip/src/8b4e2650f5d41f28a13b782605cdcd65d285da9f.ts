import {Locator, Page} from "@playwright/test";

export class homePage {
    readonly MyAccountBtn: Locator;

    constructor(private readonly page: Page) {
        this.MyAccountBtn = page.locator("//span[@aria-expanded='false']");
    }

    async clickMyAccountBtn(): Promise<void> {
        await this.MyAccountBtn.click();
    }
}